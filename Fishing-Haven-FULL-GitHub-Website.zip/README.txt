Fishing Haven - GitHub Pages Website

Upload the contents of this folder to the root of your GitHub repository:
- index.html
- assets/ folder

Then in GitHub:
Settings -> Pages -> Deploy from a branch -> main -> /(root)

The homepage uses the exact approved Fishing Haven screenshot unchanged.
